use employee;

select emp_id, first_name, last_name, gender, dept
from emp_record_table
order by dept;

select emp_id, first_name, last_name, gender, dept, emp_rating
from emp_record_table
where emp_rating<2;

select emp_id, first_name, last_name, gender, dept, emp_rating
from emp_record_table
where emp_rating>4;

select emp_id, first_name, last_name, gender, dept, emp_rating
from emp_record_table
where emp_rating between 2 and 4;

select concat(first_name," ", last_name) as Name
from emp_record_table
where dept  = "FINANCE";

SELECT m.emp_id, m.first_name AS Manager_Name, COUNT(e.first_name) AS reportees
FROM emp_record_table e, emp_record_table m
WHERE e.manager_id = m.emp_id
GROUP BY m.emp_id, m.first_name;


select emp_id, first_name, dept from emp_record_table where dept = "HEALTHCARE"
union
select emp_id, first_name, dept from emp_record_table where dept = "FINANCE";


SELECT emp_id, first_name, last_name,role,dept,emp_rating,
max(emp_rating) over(partition by dept) as max_emp_rating_dept
from emp_record_table;


select emp_id, first_name, last_name, role, dept, salary,
max(salary) over(partition by role) as max_salary,
min(salary) over(partition by role) as min_salary
from emp_record_table;


select emp_id, first_name, last_name, dept, exp,
rank() over(order by exp desc) emp_exp_rank,
dense_rank() over(order by exp desc) emp_exp_dense_rank
from emp_record_table;

create view v_emp as 
select * from emp_record_table where salary>6000;
select * from v_emp;

select e.emp_id,e.first_name,e.exp
from emp_record_table e
where e.emp_id in 
(select s.emp_id from emp_record_table s 
where s.exp>10)
order by exp desc;


DELIMITER //

CREATE PROCEDURE sp_get_experienced_employees()
BEGIN
    SELECT * 
    FROM emp_record_table
    WHERE exp > 3;
END; //

DELIMITER ;

CALL sp_get_experienced_employees();


DELIMITER //

CREATE FUNCTION fn_prof_match(e_id VARCHAR(4)) 
RETURNS VARCHAR(50) 
DETERMINISTIC
BEGIN
    -- Declaration of variables
    DECLARE emp_exp INT;
    DECLARE emp_role VARCHAR(24);
    DECLARE std_role VARCHAR(24);

    -- Fetching the employee's experience and role
    SELECT exp, role INTO emp_exp, emp_role
    FROM data_science_team
    WHERE emp_id = e_id;

    -- Determine the standard role based on experience
    IF emp_exp <= 2 THEN 
        SET std_role = 'JUNIOR DATA SCIENTIST';
    ELSEIF emp_exp > 2 AND emp_exp <= 5 THEN
        SET std_role = 'ASSOCIATE DATA SCIENTIST';
    ELSEIF emp_exp > 5 AND emp_exp <= 10 THEN
        SET std_role = 'SENIOR DATA SCIENTIST';
    ELSEIF emp_exp > 10 AND emp_exp <= 12 THEN
        SET std_role = 'LEAD DATA SCIENTIST';
    ELSE
        SET std_role = 'OTHER ROLE';
    END IF;

    -- Compare and return the result
    IF emp_role = std_role THEN
        RETURN 'Profile matches standard.';
    ELSE
        RETURN 'Profile does not match standard.';
    END IF;

END //

DELIMITER ;


SHOW FUNCTION STATUS WHERE db = 'employee';
SELECT fn_prof_match('E005');
SELECT fn_prof_match('E007');


-- Index- To reduce query cost
select * from emp_record_table where first_name = "Eric";

create index emp_fn_id on emp_record_table(first_name(7));
select * from emp_record_table where first_name = "Eric";


select emp_id, first_name, salary, emp_rating,(0.05*salary*emp_rating) as BONUS
from emp_record_table
order by BONUS desc ; #to show the highest bonus 


SELECT emp_id, first_name, last_name, salary, country, continent,
       AVG(salary) OVER (PARTITION BY country) AS avg_country_salary,
       AVG(salary) OVER (PARTITION BY continent) AS avg_continent_salary
FROM emp_record_table
ORDER BY avg_continent_salary DESC, avg_country_salary DESC;





